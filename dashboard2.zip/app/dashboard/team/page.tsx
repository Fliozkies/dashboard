export default function TeamPage() {
  return (
    <div className="p-7">
      <div className="text-[11px] text-[#4a9eff] tracking-[3px] uppercase mb-1" style={{ fontFamily: "var(--font-space-mono)" }}>// team</div>
      <div className="text-[20px] font-semibold text-[#e8f0ff] mb-6">Team Members</div>
      <div className="text-[13px] text-[#3d5278]">Coming soon — individual dev profiles &amp; GitHub activity.</div>
    </div>
  );
}
