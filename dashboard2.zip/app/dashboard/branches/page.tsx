export default function BranchesPage() {
  return (
    <div className="p-7">
      <div className="text-[11px] text-[#4a9eff] tracking-[3px] uppercase mb-1" style={{ fontFamily: "var(--font-space-mono)" }}>// branches</div>
      <div className="text-[20px] font-semibold text-[#e8f0ff] mb-6">Branch Review</div>
      <div className="text-[13px] text-[#3d5278]">Coming soon — propose, diff, and merge branches with reviewer flow.</div>
    </div>
  );
}
