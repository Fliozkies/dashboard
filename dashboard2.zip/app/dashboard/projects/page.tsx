export default function ProjectsPage() {
  return (
    <div className="p-7">
      <div className="text-[11px] text-[#4a9eff] tracking-[3px] uppercase mb-1" style={{ fontFamily: "var(--font-space-mono)" }}>// projects</div>
      <div className="text-[20px] font-semibold text-[#e8f0ff] mb-6">All Projects</div>
      <div className="text-[13px] text-[#3d5278]">Coming soon — workspace view with live preview &amp; annotations.</div>
    </div>
  );
}
