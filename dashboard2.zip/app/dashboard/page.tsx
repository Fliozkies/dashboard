import MetricCard from "../components/MetricCard";
import CommitChart from "../components/CommitChart";
import SprintProgress from "../components/SprintProgress";
import TeamPanel from "../components/TeamPanel";
import RecentCommits from "../components/RecentCommits";
import PullRequests from "../components/PullRequests";
import ZonesPanel from "../components/ZonesPanel";

const metrics = [
  {
    label: "Commits",
    value: "147",
    sub: "this sprint",
    delta: "↑ 23%",
    deltaUp: true,
    barPct: 73,
    barColor: "linear-gradient(90deg,#1a3060,#4a9eff)",
  },
  {
    label: "PRs Merged",
    value: "34",
    sub: "of 41 open",
    delta: "↑ 8%",
    deltaUp: true,
    barPct: 83,
    barColor: "linear-gradient(90deg,#052210,#22c55e)",
  },
  {
    label: "Issues Closed",
    value: "62",
    sub: "of 78 total",
    delta: "↓ 3%",
    deltaUp: false,
    barPct: 79,
    barColor: "linear-gradient(90deg,#1f1500,#f59e0b)",
  },
  {
    label: "Code Review",
    value: "2.1h",
    sub: "avg turnaround",
    delta: "↑ fast",
    deltaUp: true,
    barPct: 60,
    barColor: "linear-gradient(90deg,#200520,#a855f7)",
  },
];

export default function DashboardPage() {
  return (
    <div className="p-7 min-h-screen">
      {/* Top bar */}
      <div className="flex items-center justify-between mb-7">
        <div>
          <div
            className="text-[11px] text-[#4a9eff] tracking-[3px] uppercase mb-1"
            style={{ fontFamily: "var(--font-space-mono)" }}
          >
            // team dashboard
          </div>
          <div className="text-[20px] font-semibold text-[#e8f0ff]">
            Sprint 7 — Overview
          </div>
        </div>
        <div className="flex gap-2.5 items-center">
          <div
            className="bg-[#0d1a30] border border-[#1a2540] rounded-full px-3.5 py-1.5 text-[12px] text-[#6b7fa3] flex items-center gap-1.5 cursor-pointer"
            style={{ fontFamily: "var(--font-space-mono)" }}
          >
            <span className="w-1.5 h-1.5 rounded-full bg-[#22c55e] shadow-[0_0_6px_#22c55e]" />
            Live sync
          </div>
          <div
            className="bg-[#0d1a30] border border-[#1a2540] rounded-full px-3.5 py-1.5 text-[12px] text-[#6b7fa3] cursor-pointer"
            style={{ fontFamily: "var(--font-space-mono)" }}
          >
            ⌘ April 2026
          </div>
        </div>
      </div>

      {/* Metric cards */}
      <div className="grid grid-cols-4 gap-4 mb-6">
        {metrics.map((m) => (
          <MetricCard key={m.label} {...m} />
        ))}
      </div>

      {/* Mid row */}
      <div className="grid gap-4 mb-6" style={{ gridTemplateColumns: "1.4fr 1fr 1fr" }}>
        <CommitChart />
        <SprintProgress />
        <TeamPanel />
      </div>

      {/* Bottom row */}
      <div className="grid gap-4" style={{ gridTemplateColumns: "1.2fr 1fr 0.9fr" }}>
        <RecentCommits />
        <PullRequests />
        <ZonesPanel />
      </div>
    </div>
  );
}
