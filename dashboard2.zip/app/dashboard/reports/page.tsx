export default function ReportsPage() {
  return (
    <div className="p-7">
      <div className="text-[11px] text-[#4a9eff] tracking-[3px] uppercase mb-1" style={{ fontFamily: "var(--font-space-mono)" }}>// reports</div>
      <div className="text-[20px] font-semibold text-[#e8f0ff] mb-6">Reports</div>
      <div className="text-[13px] text-[#3d5278]">Coming soon — CSV/PDF export with velocity &amp; burndown charts.</div>
    </div>
  );
}
