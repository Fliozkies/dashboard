import { recentCommits } from "../data";

export default function RecentCommits() {
  return (
    <div className="bg-[#0a0f1e] border border-[#1a2540] rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="text-[14px] font-medium text-[#e8f0ff]">Recent commits</div>
        <span
          className="text-[10px] px-2 py-0.5 rounded"
          style={{
            background: "#0a1428",
            color: "#4a9eff",
            border: "1px solid #1a3060",
            fontFamily: "var(--font-space-mono)",
          }}
        >
          main
        </span>
      </div>
      <div className="flex flex-col gap-2">
        {recentCommits.map((c) => (
          <div
            key={c.hash}
            className="flex items-start gap-2.5 p-2.5 rounded-lg"
            style={{ background: "#0d1222", border: "1px solid #131d32" }}
          >
            <span
              className="text-[10px] px-1.5 py-0.5 rounded flex-shrink-0 mt-0.5"
              style={{
                fontFamily: "var(--font-space-mono)",
                color: "#4a9eff",
                background: "#0a1428",
              }}
            >
              {c.hash}
            </span>
            <div className="flex-1 min-w-0">
              <div className="text-[12px] text-[#8899b8] leading-snug">{c.msg}</div>
              <div
                className="text-[11px] text-[#3d5278] mt-0.5"
                style={{ fontFamily: "var(--font-space-mono)" }}
              >
                {c.author} · {c.branch}
              </div>
            </div>
            <div
              className="text-[10px] text-[#2d3d5a] flex-shrink-0"
              style={{ fontFamily: "var(--font-space-mono)" }}
            >
              {c.time}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
