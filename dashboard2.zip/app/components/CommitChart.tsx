"use client";
import { useState } from "react";
import { weeklyCommits, weekLabels, monthlyCommits, monthLabels } from "../data";

export default function CommitChart() {
  const [tab, setTab] = useState<"week" | "month">("week");
  const data = tab === "week" ? weeklyCommits : monthlyCommits;
  const labels = tab === "week" ? weekLabels : monthLabels;
  const max = Math.max(...data);

  return (
    <div className="bg-[#0a0f1e] border border-[#1a2540] rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="text-[14px] font-medium text-[#e8f0ff]">Commit activity</div>
        <div className="flex gap-1">
          {(["week", "month"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`text-[11px] px-3 py-1 rounded border transition-all cursor-pointer ${
                tab === t
                  ? "bg-[#0d1a30] text-[#4a9eff] border-[#1a3060]"
                  : "text-[#3d5278] border-[#1a2540] hover:text-[#6b7fa3]"
              }`}
              style={{ fontFamily: "var(--font-space-mono)" }}
            >
              {t}
            </button>
          ))}
        </div>
      </div>
      <div className="flex items-end gap-1 h-[120px]">
        {data.map((v, i) => {
          const pct = Math.round((v / max) * 100);
          const isLast = i === data.length - 1;
          return (
            <div
              key={i}
              className="flex-1 rounded-t min-w-0 transition-all duration-150 cursor-pointer hover:opacity-75"
              style={{
                height: `${pct}%`,
                background: isLast ? "#4a9eff" : "#1a3060",
                boxShadow: isLast ? "0 0 8px #4a9eff44" : "none",
              }}
              title={`${v} commits`}
            />
          );
        })}
      </div>
      <div className="flex gap-1 mt-1.5">
        {labels.map((l, i) => (
          <div
            key={i}
            className="flex-1 text-center text-[9px] text-[#2d3d5a]"
            style={{ fontFamily: "var(--font-space-mono)" }}
          >
            {l}
          </div>
        ))}
      </div>
    </div>
  );
}
