import { sprintZones } from "../data";

export default function SprintProgress() {
  const overall = Math.round(sprintZones.reduce((a, z) => a + z.pct, 0) / sprintZones.length);

  return (
    <div className="bg-[#0a0f1e] border border-[#1a2540] rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div className="text-[14px] font-medium text-[#e8f0ff]">Sprint 7 progress</div>
        <span
          className="text-[11px] text-[#3d5278]"
          style={{ fontFamily: "var(--font-space-mono)" }}
        >
          8 days left
        </span>
      </div>
      <div className="flex flex-col gap-[10px]">
        {sprintZones.map((z) => (
          <div key={z.label} className="flex items-center gap-[10px]">
            <div className="text-[13px] text-[#8899b8] min-w-[72px]">{z.label}</div>
            <div className="flex-1 bg-[#0f1828] rounded h-2 overflow-hidden">
              <div
                className="h-full rounded transition-all duration-700"
                style={{ width: `${z.pct}%`, background: z.color }}
              />
            </div>
            <div
              className="text-[11px] text-[#4a9eff] min-w-[34px] text-right"
              style={{ fontFamily: "var(--font-space-mono)" }}
            >
              {z.pct}%
            </div>
          </div>
        ))}
      </div>
      <div className="mt-3.5 pt-3 border-t border-[#0f1828] flex justify-between items-center">
        <span className="text-[11px] text-[#3d5278]">Overall</span>
        <span
          className="text-[14px] text-[#4a9eff]"
          style={{ fontFamily: "var(--font-space-mono)" }}
        >
          {overall}%
        </span>
      </div>
    </div>
  );
}
